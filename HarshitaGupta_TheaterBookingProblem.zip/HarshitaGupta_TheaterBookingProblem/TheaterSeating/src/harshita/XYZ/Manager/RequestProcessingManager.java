package harshita.XYZ.Manager;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import harshita.XYZ.Action.UploadXMLAction;

public class RequestProcessingManager {
	
    private static final Log LOG = LogFactory.getLog(UploadXMLAction.class);

	
	public List<ArrayList<Integer>> processTheaterLayout(File savedTheaterFile){
 		LOG.debug(" Entering  processTheaterLayout() of RequestProcessingManager " + "...");

		FileReader reader=null;
		BufferedReader bReader=null;
		List<ArrayList<Integer>> theater = new ArrayList<ArrayList<Integer>>();
		try{
				String sCurrentLine;
			 reader= new FileReader(savedTheaterFile);
			 bReader=new BufferedReader(reader);
			
			
			 
			 while ((sCurrentLine = bReader.readLine()) != null) {
					System.out.println(sCurrentLine);
					
					ArrayList<Integer> listToken=(ArrayList<Integer>)getTokens(sCurrentLine);
					
					theater.add(listToken);
				}
			 LOG.debug(" Theater Layout List generated in RequestProcessingManager.processTheaterLayout() " + "..." + theater.toString());
		}
		catch(IOException e) {
 			LOG.error("Exception during RequestProcessingManager.processTheaterLayout():"+ e.getMessage(), e);

			e.printStackTrace();
			
		}
		finally {
			try {

				if (bReader != null)
					bReader.close();

				if (reader != null)
					reader.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}
			 return theater;
		}
		
	}
	
	public List<Integer> getTokens(String str)
	{
		 List<Integer> tokens = new ArrayList<>();
		    StringTokenizer tokenizer = new StringTokenizer(str, " ");
		    while (tokenizer.hasMoreElements()) {
		        tokens.add(Integer.parseInt(tokenizer.nextToken()));
		    }
		    return tokens;
	}

}
