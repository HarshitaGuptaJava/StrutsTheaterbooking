package harshita.XYZ.Action;

import java.io.File;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LogoutAction extends ActionSupport {
	
	ServletContext servletContext =
				ServletActionContext.getServletContext();

public String execute() {
  Map session = ActionContext.getContext().getSession();
  session.remove("theater"); 
  session.remove("requestMap");
  session.remove("savedFile"); 
  session.remove("savedTheaterFile");
  String dataDir = servletContext.getRealPath("/WEB-INF");
  File file1 = new File(dataDir,getText("TicketRequestFile"));
  File file2= new File(dataDir,getText("TheaterLayoutFile"));

  if(file1.delete()){
      System.out.println(getText("TicketRequestFile")+" deleted");
  }
  if(file2.delete()){
      System.out.println(getText("TheaterLayoutFile")+" deleted");
  }
  
  return "SUCCESS";
  }
}


