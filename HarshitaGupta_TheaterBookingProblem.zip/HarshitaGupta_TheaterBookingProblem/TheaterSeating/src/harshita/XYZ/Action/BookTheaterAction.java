package harshita.XYZ.Action;


import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import harshita.XYZ.Model.BookingList;
import harshita.XYZ.Model.Theater;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import harshita.XYZ.Manager.TheaterBookingManager;

public class BookTheaterAction extends ActionSupport implements SessionAware {

	private Map<String,Integer> requestMapFetched= new LinkedHashMap<String,Integer>();
	private static final Log LOG = LogFactory.getLog(UploadXMLAction.class);

	private Theater theater;
	private List<BookingList> booked;
	private Map<String,Object> session;
	public void setSession(Map<String,Object> session){ 
		this.session = session;
	}
	public Map<String, Integer> getRequestMapFetched() {
		return requestMapFetched;
	}

	public void setRequestMapFetched(Map<String, Integer> requestMapFetched) {
		this.requestMapFetched = requestMapFetched;
	}

	public Theater getTheater() {
		return theater;
	}

	public void setTheater(Theater theater) {
		this.theater = theater;
	}

	public List<BookingList> getBooked() {
		return booked;
	}

	public void setBooked(List<BookingList> booked) {
		this.booked = booked;
	}


	public String execute() {
		LOG.debug(" Entering  execute() of BookTheaterAction " + "...");

		TheaterBookingManager theaterBookingManager = new TheaterBookingManager();
		requestMapFetched=(Map<String,Integer>)session.get("requestMap");
		theater=(Theater)session.get("theater");
		try{
			LOG.debug(" Calling BookTheaterAction.bookTheater() " + "...");

			booked=theaterBookingManager.bookTheater(requestMapFetched,theater);
		}
		catch(Exception e) {
			e.printStackTrace();
			LOG.error("Exception in BookTheaterAction:"+ e.getMessage(), e);

			addActionError(e.getMessage());
			return "ERROR";
		}
		Iterator i= booked.iterator();
		while(i.hasNext()) {
			BookingList list=(BookingList)i.next();
			System.out.println(list.getName()+"    "+list.getSeat().getRowNum()+"   "+list.getSeat().getSectionNum());
			LOG.debug("Booking List:"+list.getName()+"    "+list.getSeat().getRowNum()+"   "+list.getSeat().getSectionNum());
		}


		return "SUCCESS";
	}
}
