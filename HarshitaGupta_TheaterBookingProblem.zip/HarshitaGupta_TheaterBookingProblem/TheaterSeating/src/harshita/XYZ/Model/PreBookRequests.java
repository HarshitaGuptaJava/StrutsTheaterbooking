package harshita.XYZ.Model;

public class PreBookRequests {

	private String customerName;
	private int NumOfTkts;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getNumOfTkts() {
		return NumOfTkts;
	}
	public void setNumOfTkts(int numOfTkts) {
		NumOfTkts = numOfTkts;
	}
	
	
	
}
