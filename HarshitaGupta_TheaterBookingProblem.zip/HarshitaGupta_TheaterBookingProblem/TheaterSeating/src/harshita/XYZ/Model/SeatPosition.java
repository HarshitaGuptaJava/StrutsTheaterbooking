package harshita.XYZ.Model;

public class SeatPosition {

	private int rowNum;
	private int sectionNum;
	
	public SeatPosition() {}
	
	public SeatPosition(int rowNum,int sectionNum) {
		this.rowNum=rowNum;
		this.sectionNum=sectionNum;
	}

	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public int getSectionNum() {
		return sectionNum;
	}
	public void setSectionNum(int sectionNum) {
		this.sectionNum = sectionNum;
	}
}
