package harshita.XYZ.Action;


import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.logging.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.util.logging.LoggerFactory;

public class UploadXMLAction extends ActionSupport implements SessionAware{

	
	private File myFile;
 	private String myFileContentType;
    private String myFileFileName; 
    private String destPath;
    private static final Log LOG = LogFactory.getLog(UploadXMLAction.class);
    private Map<String,Object> session;
    public void setSession(Map<String,Object> session){ 
        this.session = session;
    }
    
    public File getMyFile() {
 		return myFile;
 	}
 	public void setMyFile(File myFile) {
 		this.myFile = myFile;
 	}
 	public String getMyFileContentType() {
 		return myFileContentType;
 	}
 	public void setMyFileContentType(String myFileContentType) {
 		this.myFileContentType = myFileContentType;
 	}
 	public String getMyFileFileName() {
 		return myFileFileName;
 	}
 	public void setMyFileFileName(String myFileFileName) {
 		this.myFileFileName = myFileFileName;
 	}
 	public String getDestPath() {
 		return destPath;
 	}
 	public void setDestPath(String destPath) {
 		this.destPath = destPath;
 	}
    
 	public String execute() {
 		LOG.debug(" Entering  execute() of UploadXMLAction " + "...");
 		ServletContext servletContext =
 				ServletActionContext.getServletContext();
 	
 		try {
 			if (myFile != null) { 
 				
 				if(!(myFileFileName.endsWith("Ticket-Request.xml"))) {
 					 LOG.error("Incorrect XML File is added");
 					addActionError(getText("Invalid.File.request"));
 	 	 			return "INPUT";
 				}
 				String dataDir = servletContext.getRealPath("/WEB-INF");
 				File savedFile = new File(dataDir, getMyFileFileName());
 				//myFile.renameTo(savedFile);
 				FileUtils.copyFile(myFile, savedFile);
 				if(savedFile.length()> (new Long("0")).longValue()) {
 					session.put("savedFile", getMyFileFileName());
 					
 				}
 				return "SUCCESS";
 			}
 			else
 			{    LOG.error("XML File is not added");
 				addActionError(getText("File.request.required"));
 	 			return "INPUT";
 			}
 			
 		}
 		catch(IOException e)
 		{
 			LOG.error("Exception during adding XML File:"+ e.getMessage(), e);

 			e.printStackTrace();
 			addActionError(e.getMessage());
 			return "INPUT";
 		}
 		
 		
 		
    	
    }
 	
 	
 	public String printMsg() {
 		addActionMessage("You have successfully uploaded !"+ session.get("savedFile") );
 		return "SUCCESS";
 	}
 	
 	
 			

 	   
 	
	
}
