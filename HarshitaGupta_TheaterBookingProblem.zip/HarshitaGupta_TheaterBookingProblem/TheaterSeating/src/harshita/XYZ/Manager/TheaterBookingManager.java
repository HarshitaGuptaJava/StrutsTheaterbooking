package harshita.XYZ.Manager;

import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import harshita.XYZ.Action.UploadXMLAction;
import harshita.XYZ.Model.BookingList;
import harshita.XYZ.Model.SeatPosition;
import harshita.XYZ.Model.Theater;

public class TheaterBookingManager {
    private static final Log LOG = LogFactory.getLog(UploadXMLAction.class);


	List<BookingList> theaterBooking= new ArrayList<BookingList>();
	//Theater t=new Theater();
	public List<BookingList> bookTheater(Map<String,Integer> requestMap,Theater t)throws Exception {

 		LOG.debug(" Entering  bookTheater() of TheaterBookingManager " + "...");


		SeatPosition seat;
		List<ArrayList<Integer>> listOLists = t.getSampleLayout();
		int a=t.getSampleLayout().size();
		//Integer[][] layout=t.getSampleLayout();
		Integer[][] layout=new Integer[a][];
		Iterator<ArrayList<Integer>> iterator = listOLists.iterator();
        int m = 0;
        while(iterator.hasNext()){
        	Object[] o=iterator.next().toArray();
        	layout[m] = Arrays.copyOf(o, o.length,Integer[].class);
        	m++;
        }
		int totalseats=calculateTotalSeats(layout);
		for (String key: requestMap.keySet()) {
			System.out.println(key);
			int currentRequest= requestMap.get(key);
			int flagbooked=0;
			int flagsplit=0;
			int counter=0;
			if(currentRequest>totalseats) {
				seat=new SeatPosition(0,0);
				populateBookingList(new BookingList(key,seat));
				flagbooked=1;
			}
			for(int i=0;i<layout.length;i++) {
				for(int j=0;j<layout[i].length;j++){

					counter++;
					if(currentRequest>layout[i][j]) {
						flagsplit++;
					}else
						flagsplit=0;
				}
			}
			if (flagsplit==counter && flagbooked==0) {
				seat=new SeatPosition(999,999);
				populateBookingList(new BookingList(key,seat));
				flagbooked =1;
			}
			if(flagbooked ==0 ) {
				for(int i=0;i<layout.length;i++) {
					for(int j=0;j<layout[i].length;j++){


						if(layout[i][j] >= currentRequest) {
							if(layout[i][j] > currentRequest && (layout[i][j]-currentRequest)>1)
							{
								layout[i][j]=layout[i][j]-currentRequest;
								seat=new SeatPosition(i+1,j+1);
								totalseats=totalseats-currentRequest;
								populateBookingList(new BookingList(key,seat));
								flagbooked=1;
								break;
							}
							else if(layout[i][j] == currentRequest){
								layout[i][j]=layout[i][j]-currentRequest;
								seat=new SeatPosition(i+1,j+1);
								populateBookingList(new BookingList(key,seat));
								flagbooked=1;
								break;
							}
						}


					}
					if(flagbooked==1)
						break;
				}
			}
		}
 		LOG.debug(" Returning  bookTheater() of TheaterBookingManager " + "...");

		return 	theaterBooking;
	}

	public void populateBookingList(BookingList booking)
	{

		theaterBooking.add(booking);

	}

	public int calculateTotalSeats(Integer[][] layout) {
		int total=0;
		for(int i=0;i<layout.length;i++) {
			for(int j=0;j<layout[i].length;j++) {

				total=total+layout[i][j];
			}
		}
		return total;
	}
}
