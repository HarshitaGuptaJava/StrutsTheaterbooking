	package harshita.XYZ.Model;

public class BookingList {
	
	private String name;
	private SeatPosition seat;
	
	public BookingList(){
		
	}
	
	public BookingList(String name,SeatPosition seat){
		
		this.name=name;
		this.seat=seat;		
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public SeatPosition getSeat() {
		return seat;
	}
	public void setSeat(SeatPosition seat) {
		this.seat = seat;
	}

}
