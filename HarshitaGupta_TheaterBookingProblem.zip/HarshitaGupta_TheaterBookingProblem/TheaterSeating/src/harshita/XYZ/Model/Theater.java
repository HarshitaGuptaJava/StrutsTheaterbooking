package harshita.XYZ.Model;

import java.util.*;

public class Theater {
	
	private int totalSeatsAvailable;
	private SeatPosition position;

	private List<ArrayList<Integer>> sampleLayout;// = {{6,6},{3,5,5,3},{4,6,6,4},{2,8,8,2},{6,6}};  
	
	public List<ArrayList<Integer>> getSampleLayout() {
		return sampleLayout;
	}
	public void setSampleLayout(List<ArrayList<Integer>> sampleLayout) {
		this.sampleLayout = sampleLayout;
	}
	public int getTotalSeatsAvailable() {
		return totalSeatsAvailable;
	}
	public void setTotalSeatsAvailable(int totalSeatsAvailable) {
		this.totalSeatsAvailable = totalSeatsAvailable;
	}
	

	
	public SeatPosition getPosition() {
		return position;
	}
	public void setPosition(SeatPosition position) {
		this.position = position;
	}
	
}
