package harshita.XYZ.Action;

import java.io.File;
import java.io.IOException;
import java.util.*;

import javax.servlet.ServletContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;
import org.w3c.dom.*;

import com.opensymphony.xwork2.ActionSupport;

import harshita.XYZ.Manager.RequestProcessingManager;
import harshita.XYZ.Model.Theater;

public class CustomerRequestProcessing extends ActionSupport implements SessionAware {

	private Map<String,Integer> requestMap= new LinkedHashMap<String,Integer>();
	private Map<String,Object> session;
	private Theater theater=new Theater();

	public void setSession(Map<String,Object> session){ 
		this.session = session;
	}
	public Map<String, Integer> getRequestMap() {
		return requestMap;
	}

	public void setRequestMap(Map<String, Integer> requestMap) {
		this.requestMap = requestMap;
	}

	public String execute() {
		ServletContext servletContext =	ServletActionContext.getServletContext();

		String requestFileName=getText("TicketRequestFile");
		String theaterLayoutFileName=getText("TheaterLayoutFile");
		try {
			String name=null;
			int NoOfTickets=0;
			String dataDir = servletContext.getRealPath("/WEB-INF");
			File savedFile = new File(dataDir, requestFileName);

			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = null;
			doc = dBuilder.parse(savedFile);
			//doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName("request");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				System.out.println("\nCurrent Element :" + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;

					System.out.println("Request id : " + eElement.getAttribute("id"));
					System.out.println(" Name : " + eElement.getElementsByTagName("name").item(0).getTextContent());
					name=eElement.getElementsByTagName("name").item(0).getTextContent();

					System.out.println("NoOfTickets : " + eElement.getElementsByTagName("NumOfTicket").item(0).getTextContent());
					NoOfTickets=Integer.parseInt(eElement.getElementsByTagName("NumOfTicket").item(0).getTextContent());

					requestMap.put(name, NoOfTickets);
					session.put("requestMap", requestMap);
				}
			}

		}
		catch(Exception e) {
			e.printStackTrace();
			return "ERROR";
		}
		try {
			String dataDir = servletContext.getRealPath("/WEB-INF");
			File SavedTheaterFile =new  File(dataDir, theaterLayoutFileName);		
			RequestProcessingManager rpManager= new RequestProcessingManager();
			theater.setSampleLayout(rpManager.processTheaterLayout(SavedTheaterFile));
			session.put("theater", theater);
			
		}
		catch(Exception e1){
			e1.printStackTrace();
			return "ERROR";
		}
		return "SUCCESS";
	}




}
