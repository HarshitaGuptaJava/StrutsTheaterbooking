The XYZ TheaterBooking App has been built on eclipse and tested on Tomcat 9

It is based on Struts2 MVC framework
with 

Model files
_____________
BookingList.java
SeatPosition.java
Theater.java

Action Files
_________________
BookTheaterAction.java
CustomerRequestProcessing.java
LogoutAction.java
UploadTheaterAction.java
UploadXMLAction.java

Manager Classes
_____________________
RequestProcessingManager.java
TheaterBookingManager.java

Global Resource Bundle
___________________
TheaterResources.properties

Configuration
______________________
struts.xml
web.xml

Input Files
___________________
Theater-Layout.txt
Ticket-Request.xml

CSS
_____________
main.css

JSP pages
_____________
ListBooking.jsp
TheaterBooking.jsp
XYZTheaterHome.jsp
error.jsp


To Test the Application

Place the Source Folder In Eclipse and rightClick and export to war 
Deploy TheaterSeating.war in Tomcat webapps folder, and restart Tomcat if already running.
Once Start
in Browser type link  http://localhost:8085/TheaterSeating/XYZTheaterBooking.action

and using the steps in  TheaterBooking_test_screenshot.doc run the application.

About Source Code

When file Theater-Layout.txt is uploaded UploadTheaterAction.java
When file Ticket-Request.xml is uploaded UploadXMLAction.java is called once upload is complete 
Parse Request Link calls CustomerRequestProcessing.java Action


The Theater-Layout.txt has layout of theater as given in the problem. 
the layout is parsed and put in a LIST of Arraylist which is then RequestProcessingManager.processTheaterLayout() 
and   Ticket-Request.xml is parsed to produce a Map(Name,NoOFTickets)

further BookedTheaterAction is chained in where the execute method calls TheaterBookingManager.bookTheater() method. bookTheater() has the logic to assign row and section to each request(Main logic of the Problem) and OUTput is displayed on ListBooking.jsp




